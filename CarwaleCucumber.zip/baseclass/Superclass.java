package baseclass;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;

public class Superclass {
	
	public static ChromeDriver driver;
	public static JavascriptExecutor js;
	

}
