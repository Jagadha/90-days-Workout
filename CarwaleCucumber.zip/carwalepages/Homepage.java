package carwalepages;

import org.openqa.selenium.Keys;

import baseclass.Superclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Homepage extends Superclass {
	
	@Given("Click on Used")
	public Homepage clickUsed() throws InterruptedException {
		driver.findElementByXPath("//li[@data-tabs='usedCars']").click();
		return this;
	}
	
	@Given("Select the City as Chennai")
	public Homepage selectlocation() throws InterruptedException {
		driver.findElementById("usedCarsList").sendKeys("Chennai");
		Thread.sleep(3000);
		driver.findElementById("usedCarsList").sendKeys(Keys.ENTER);
		return this;
	}
	
	@Given("Select min budget as 8L")
	public Homepage selectMinValue() {
		driver.findElementByXPath("//li[text()='8 Lakh']").click();
		return this;
	}
	
	@When("Select max budget as 12L")
	public Homepage selectMaxValue() {
		driver.findElementByXPath("(//li[text()='12 Lakh'])[2]").click();
		return this;
	}
	
	@Then("Click Search")
	public Carlistpage clickSearch() {
		driver.findElementById("btnFindCar").click();
		return new Carlistpage();
	}

}
