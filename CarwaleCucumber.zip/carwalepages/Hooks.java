package carwalepages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import baseclass.Superclass;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks extends Superclass{
	
	@Before
	public void launchURL() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		driver =  new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		js = (JavascriptExecutor) driver;
		
		driver.get("https://www.carwale.com/");
	}
	
	@After
	public void closeBrowser() {
		driver.close();
	}

}
