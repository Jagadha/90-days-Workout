package carwalepages;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.openqa.selenium.WebElement;

import baseclass.Superclass;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OverviewofCar extends Superclass{
	
	@When("Click on More Details")
	public OverviewofCar clickMoreDetails() {
		driver.findElementByLinkText("More details �").click();
		return this;
	}
	
	@Then("Print all the details under Overview")
	public OverviewofCar PrintAllDetails() {
		Set<String> wH = driver.getWindowHandles();
		List<String> lwH = new ArrayList<>(wH);
		driver.switchTo().window(lwH.get(1));
		List<WebElement> light = driver.findElementsByXPath("//div[@id='overview']//ul//div[@class='equal-width text-light-grey']");
		List<WebElement> dark = driver.findElementsByXPath("//div[@id='overview']//ul//div[@class='equal-width dark-text']");
		Map<String, String> m = new LinkedHashMap<>();

		for (int j = 0; j < light.size(); j++) {
			String desc = light.get(j).getText();
			String val = dark.get(j).getText();
			m.put(desc, val);
		}
		
		for (Entry<String, String> eachm : m.entrySet()) {
			
			System.out.println(eachm.getKey()+"\t\t\t"+eachm.getValue());
			
		}
		return this;
	}

}
